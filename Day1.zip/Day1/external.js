//accept 2 numbers from user -prompt
var num1=Number(prompt("Enter first number = "))
var num2=Number(prompt("Enter second number = "))

// 2 functions to calculate addition and multiplication

function add(n1,n2){
    return(n1+n2)
}

function mult(n11,n22){
    return(n11*n22)
}

// assign the result to specific span id
document.getElementById('spanadd').innerText=add(num1,num2)
document.getElementById('spanmult').innerText=mult(num1,num2)